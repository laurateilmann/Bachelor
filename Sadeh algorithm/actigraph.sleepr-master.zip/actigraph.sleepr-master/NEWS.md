# actigraph.sleepr 0.2.0

* Fixes bugs and updates to `dplyr` and `tidyr`.

# actigraph.sleepr 0.1.0

* Initial release for sleep detection using standard algorithms.
