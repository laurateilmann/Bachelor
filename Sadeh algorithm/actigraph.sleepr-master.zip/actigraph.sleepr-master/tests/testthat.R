library(testthat)
library(tidyr)
library(dplyr)
library(actigraph.sleepr)

test_check("actigraph.sleepr")
