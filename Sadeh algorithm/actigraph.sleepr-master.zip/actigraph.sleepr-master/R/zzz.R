.onUnload <- function(libpath) {
  library.dynam.unload("actigraph.sleepr", libpath)
}
